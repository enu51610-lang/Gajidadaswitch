package com.gajidadaswitch.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private Button btnApMode, btnRouterMode;
    private SharedPreferences sharedPreferences;
    
    private String apIpUrl = "http://192.168.4.1";
    private String savedRouterIp = "";
    
    private ExecutorService executorService;
    private Handler mainHandler;
    private boolean isScanning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        btnApMode = findViewById(R.id.btnApMode);
        btnRouterMode = findViewById(R.id.btnRouterMode);

        sharedPreferences = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        savedRouterIp = sharedPreferences.getString("router_ip", "");

        executorService = Executors.newFixedThreadPool(10);
        mainHandler = new Handler(Looper.getMainLooper());

        // वेबव्यू सेटिंग्स
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        // शुरुआत में AP मोड लोड करें
        loadUrlSafely(apIpUrl);
        updateButtonStyles(true);

        // AP मोड बटन क्लिक
        btnApMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadUrlSafely(apIpUrl);
                updateButtonStyles(true);
                Toast.makeText(MainActivity.this, "Connecting to AP Mode...", Toast.LENGTH_SHORT).show();
            }
        });

        // राउटर मोड बटन क्लिक (अगर आईपी सेव है तो डायरेक्ट खोलेगा, वरना स्कैन करेगा)
        btnRouterMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isScanning) {
                    Toast.makeText(MainActivity.this, "Scanning is already running...", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!savedRouterIp.isEmpty()) {
                    loadUrlSafely(savedRouterIp);
                    updateButtonStyles(false);
                    Toast.makeText(MainActivity.this, "Connecting to Saved Router IP...", Toast.LENGTH_SHORT).show();
                } else {
                    startIpScanAndConnect();
                }
            }
        });
        
        // राउटर बटन को दबाकर रखने (Long Press) पर दोबारा नया आईपी स्कैन करेगा
        btnRouterMode.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(MainActivity.this, "Rescanning network for ESP32...", Toast.LENGTH_SHORT).show();
                startIpScanAndConnect();
                return true;
            }
        });
    }

    private void startIpScanAndConnect() {
        isScanning = true;
        btnRouterMode.setText("Scanning IP...");
        Toast.makeText(this, "Searching for Gaji Dada Switch on Router...", Toast.LENGTH_LONG).show();

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                String foundIp = "";
                String subnet = "192.168.1."; 

                for (int i = 1; i <= 254; i++) {
                    if (!isScanning) break;
                    String testUrl = "http://" + subnet + i;
                    if (isDeviceGajiSwitch(testUrl)) {
                        foundIp = testUrl;
                        break;
                    }
                }

                final String finalIp = foundIp;
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        isScanning = false;
                        btnRouterMode.setText("Router Mode");
                        if (!finalIp.isEmpty()) {
                            savedRouterIp = finalIp;
                            sharedPreferences.edit().putString("router_ip", savedRouterIp).apply();
                            
                            loadUrlSafely(savedRouterIp);
                            updateButtonStyles(false);
                            Toast.makeText(MainActivity.this, "Found & Saved: " + savedRouterIp, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "ESP32 not found on network! Check WiFi.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }

    private boolean isDeviceGajiSwitch(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(300);
            conn.setReadTimeout(300);
            conn.setRequestMethod("GET");
            if (conn.getResponseCode() == 200) {
                return true;
            }
        } catch (IOException e) {
            // इग्नोर करें
        }
        return false;
    }

    private void loadUrlSafely(String url) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url;
        }
        webView.loadUrl(url);
    }

    private void updateButtonStyles(boolean isApActive) {
        if (isApActive) {
            btnApMode.setBackgroundTintList(getResources().getColorStateList(android.R.color.white));
            btnApMode.setTextColor(getResources().getColor(android.R.color.black));
            
            btnRouterMode.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
            btnRouterMode.setTextColor(getResources().getColor(android.R.color.white));
        } else {
            btnRouterMode.setBackgroundTintList(getResources().getColorStateList(android.R.color.white));
            btnRouterMode.setTextColor(getResources().getColor(android.R.color.black));
            
            btnApMode.setBackgroundTintList(getResources().getColorStateList(android.R.color.darker_gray));
            btnRouterMode.setTextColor(getResources().getColor(android.R.color.white));
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}