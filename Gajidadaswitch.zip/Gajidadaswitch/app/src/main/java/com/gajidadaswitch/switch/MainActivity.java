package com.gajidadaswitch.switch;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private Button btnConnectAp, btnOpenDashboard, btnSaveRouter;
    private EditText etSsid, etPass;
    
    // ESP32 AP Mode Default IP
    private String currentIp = "http://192.168.4.1"; 
    private OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnConnectAp = findViewById(R.id.btnConnectAp);
        btnOpenDashboard = findViewById(R.id.btnOpenDashboard);
        btnSaveRouter = findViewById(R.id.btnSaveRouter);
        etSsid = findViewById(R.id.etSsid);
        etPass = findViewById(R.id.etPass);

        // 1. ESP32 हॉटस्पॉट से कनेक्ट होने का बटन
        btnConnectAp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connectToEspHotspot("Ghazi_Dada_Switch", "12345678");
            }
        });

        // 2. डैशबोर्ड खोलने का बटन (AP या Router मोड जो भी एक्टिव हो)
        btnOpenDashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(currentIp));
                startActivity(intent);
            }
        });

        // 3. राउटर वाई-फाई आईडी-पासवर्ड ESP32 को भेजने का बटन
        btnSaveRouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ssid = etSsid.getText().toString().trim();
                String pass = etPass.getText().toString().trim();
                
                if(!ssid.isEmpty()) {
                    sendRouterCredentialsToEsp(ssid, pass);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter Router SSID", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // एंड्रॉइड के लिए ESP32 वाई-फाई हॉटस्पॉट से सीधे जोड़ने का फंक्शन
    private void connectToEspHotspot(String ssid, String password) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            WifiNetworkSpecifier specifier = new WifiNetworkSpecifier.Builder()
                    .setSsid(ssid)
                    .setWpa2Passphrase(password)
                    .build();

            NetworkRequest request = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .setNetworkSpecifier(specifier)
                    .build();

            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            connectivityManager.requestNetwork(request, new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    super.onAvailable(network);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        connectivityManager.bindProcessToNetwork(network);
                    }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Connected to ESP32 AP!", Toast.LENGTH_SHORT).show());
                }
            });
        } else {
            Toast.makeText(this, "Please connect 'Ghazi_Dada_Switch' manually in Wi-Fi settings", Toast.LENGTH_LONG).show();
        }
    }

    // राउटर के डिटेल्स ESP32 को भेजना और उसकी नई IP प्राप्त करना
    private void sendRouterCredentialsToEsp(String ssid, String pass) {
        String url = "http://192.168.4.1/savewifi?ssid=" + ssid + "&pass=" + pass;

        Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Failed to send credentials", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful) {
                    String assignedIp = response.body().string(); // ESP32 राउटर से मिलने वाली IP वापस भेजेगा
                    runOnUiThread(() -> {
                        if (assignedIp != null && !assignedIp.isEmpty()) {
                            currentIp = "http://" + assignedIp.trim();
                            Toast.makeText(MainActivity.this, "Connected to Router! IP: " + assignedIp, Toast.LENGTH_LONG).show();
                            btnOpenDashboard.setText("OPEN ROUTER DASHBOARD (" + assignedIp + ")");
                        } else {
                            Toast.makeText(MainActivity.this, "Saved! Check router connection.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
